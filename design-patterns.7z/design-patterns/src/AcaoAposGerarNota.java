
public interface AcaoAposGerarNota {
	//DP: Observer
	public void executa(NotaFiscal notaFiscal);
}
