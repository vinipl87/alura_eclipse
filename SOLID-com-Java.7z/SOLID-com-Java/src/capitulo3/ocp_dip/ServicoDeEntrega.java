package capitulo3.ocp_dip;

public interface ServicoDeEntrega {
	double para(String cidade);
}