package capitulo3.ocp_dip;

public interface TabelaDePreco {
	double descontoPara(double valor);
}
