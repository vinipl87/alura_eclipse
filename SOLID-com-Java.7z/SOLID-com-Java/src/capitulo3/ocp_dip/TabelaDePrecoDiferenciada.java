package capitulo3.ocp_dip;

public class TabelaDePrecoDiferenciada implements TabelaDePreco {

	@Override
	public double descontoPara(double valor) {
		// TODO Auto-generated method stub
		return 0;
	}

}
