package capitulo4.encapsulamento_isp;

public enum MeioDePagamento {

    BOLETO,
    CARTAO
}
