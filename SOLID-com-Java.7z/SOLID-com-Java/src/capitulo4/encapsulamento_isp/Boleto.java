package capitulo4.encapsulamento_isp;

public class Boleto {

    private double valor;


    public Boleto(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }


}