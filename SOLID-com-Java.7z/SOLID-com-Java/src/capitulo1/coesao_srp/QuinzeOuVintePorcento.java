package capitulo1.coesao_srp;

public class QuinzeOuVintePorcento implements RegraDeCalculo{

	@Override
	public double calcula(Funcionario funcionario) {
		return 0;
	}

}
