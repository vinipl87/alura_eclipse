package capitulo1.coesao_srp;

public interface RegraDeCalculo {
	public double calcula(Funcionario funcionario);
}
