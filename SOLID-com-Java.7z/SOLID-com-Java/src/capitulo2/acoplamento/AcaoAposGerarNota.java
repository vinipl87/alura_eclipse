package capitulo2.acoplamento;

public interface AcaoAposGerarNota {
	void executa(NotaFiscal nf);
}
