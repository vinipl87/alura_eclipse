package cap7.command;

public interface Comando {
	public void executa();
}
