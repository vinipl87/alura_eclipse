package cap3.memento;

public enum TipoContrato {
	NOVO, EM_ANDAMENTO, ACERTADO, CONCLUIDO
}
