package cap6.bridge_adapter;

public class MapLink implements Mapa{

	@Override
	public String devolveMapa(String rua) {
		return "mapa do maplink";
	}

}
