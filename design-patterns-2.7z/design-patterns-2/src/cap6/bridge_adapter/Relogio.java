package cap6.bridge_adapter;

import java.util.Calendar;

public interface Relogio {
	public Calendar hoje();
}
