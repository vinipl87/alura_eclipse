package cap6.bridge_adapter;

public interface Mapa {
	//DP: Bridge
	String devolveMapa(String rua);
}
