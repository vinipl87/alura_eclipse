package cap2.flyweight;

public class SiSustenido implements Nota {

	@Override
	public String simbolo() {
		return "B#";
	}
}