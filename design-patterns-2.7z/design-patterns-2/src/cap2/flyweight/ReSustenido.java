package cap2.flyweight;

public class ReSustenido implements Nota {

	@Override
	public String simbolo() {
		return "D#";
	}
}