package cap2.flyweight;

public interface Nota {
	String simbolo();
}
