package cap2.flyweight;

public class Si implements Nota {

	@Override
	public String simbolo() {
		return "B";
	}

}
