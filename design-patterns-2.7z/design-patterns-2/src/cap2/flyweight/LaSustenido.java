package cap2.flyweight;

public class LaSustenido implements Nota {

	@Override
	public String simbolo() {
		return "C#";
	}
}