package cap2.flyweight;

public class MiSustenido implements Nota {

	@Override
	public String simbolo() {
		return "E#";
	}
}