package cap2.flyweight;

public class Do implements Nota {

	@Override
	public String simbolo() {
		return "C";
	}

}
