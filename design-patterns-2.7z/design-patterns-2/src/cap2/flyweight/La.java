package cap2.flyweight;

public class La implements Nota {

	@Override
	public String simbolo() {
		return "A#";
	}

}
