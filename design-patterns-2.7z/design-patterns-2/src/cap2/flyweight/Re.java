package cap2.flyweight;

public class Re implements Nota {

	@Override
	public String simbolo() {
		return "D";
	}

}
