package cap2.flyweight;

public class Fa implements Nota {

	@Override
	public String simbolo() {
		return "F";
	}

}
