package cap2.flyweight;

public class DoSustenido implements Nota {

	@Override
	public String simbolo() {
		return "C#";
	}
}