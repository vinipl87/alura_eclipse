package cap2.flyweight;

public class SolSustenido implements Nota {

	@Override
	public String simbolo() {
		return "G#";
	}
}