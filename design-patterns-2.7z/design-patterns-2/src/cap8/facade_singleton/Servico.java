package cap8.facade_singleton;

class Servico {
	protected Servico() {
	}

	// outros metodos aqui
}